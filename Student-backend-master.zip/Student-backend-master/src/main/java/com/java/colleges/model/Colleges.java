package com.java.colleges.model;

import javax.persistence.Id;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="colleges")
public class Colleges {

	    
	    @Id
	    public ObjectId _id;
		private Long categoryId; 
		private String categoryName; //MBA, MS_COMPUTER, MBBS, MS_CHEMICAL, MS_MPH, AI 
	    private String resourceType;	//website, video, twitter #hashtag
	    private String collegeUrl;	
	    private String collegeFacts;	
	    private String collegeScores;
	    private String internationalStudentsRatio;
	    private String maleFemaleRatio;
	    private String collegeResearchGrants;	//high, average, low
	    private String authorName;  		//author 
	    private String contributorName;   	//contributor
	    private String contributorEmail;
	    private String contributorStoryLine;
	  	private String collegeStanding;    //high or good or average or below average
		private String collegeGPA;	
	    private String collegeScholarships;	//
	    private String collegeCampusLife;	//high or good or average or below average
	    private String cityName;
	    private String stateName;
	    private String countryCode;
	    private String countryName;
	    private String resourceUploadedDate;
	    private String collegeLocation;
	    private String notes;
	    private String lastModifiedBy;
	    private String lastModifiedDate;
		private String localCampusInfo;    //categoryPage news
		private String alumniInfo;   //categoryPage pictures
		private String prospectus;// subCategoryPage pictures
	 

		public Colleges() {
			
		}


		public Colleges(ObjectId _id, Long categoryId, String categoryName, String resourceType, String collegeUrl,
				String collegeFacts, String collegeScores, String internationalStudentsRatio, String maleFemaleRatio,
				String collegeResearchGrants, String authorName, String contributorName, String contributorEmail,
				String contributorStoryLine, String collegeStanding, String collegeGPA, String collegeScholarships,
				String collegeCampusLife, String cityName, String stateName, String countryCode, String countryName,
				String resourceUploadedDate, String collegeLocation, String notes, String lastModifiedBy,
				String lastModifiedDate, String localCampusInfo, String alumniInfo, String prospectus) {
			super();
			this._id = _id;
			this.categoryId = categoryId;
			this.categoryName = categoryName;
			this.resourceType = resourceType;
			this.collegeUrl = collegeUrl;
			this.collegeFacts = collegeFacts;
			this.collegeScores = collegeScores;
			this.internationalStudentsRatio = internationalStudentsRatio;
			this.maleFemaleRatio = maleFemaleRatio;
			this.collegeResearchGrants = collegeResearchGrants;
			this.authorName = authorName;
			this.contributorName = contributorName;
			this.contributorEmail = contributorEmail;
			this.contributorStoryLine = contributorStoryLine;
			this.collegeStanding = collegeStanding;
			this.collegeGPA = collegeGPA;
			this.collegeScholarships = collegeScholarships;
			this.collegeCampusLife = collegeCampusLife;
			this.cityName = cityName;
			this.stateName = stateName;
			this.countryCode = countryCode;
			this.countryName = countryName;
			this.resourceUploadedDate = resourceUploadedDate;
			this.collegeLocation = collegeLocation;
			this.notes = notes;
			this.lastModifiedBy = lastModifiedBy;
			this.lastModifiedDate = lastModifiedDate;
			this.localCampusInfo = localCampusInfo;
			this.alumniInfo = alumniInfo;
			this.prospectus = prospectus;
		}


		public ObjectId get_id() {
			return _id;
		}


		public void set_id(ObjectId _id) {
			this._id = _id;
		}


		public Long getCategoryId() {
			return categoryId;
		}


		public void setCategoryId(Long categoryId) {
			this.categoryId = categoryId;
		}


		public String getCategoryName() {
			return categoryName;
		}


		public void setCategoryName(String categoryName) {
			this.categoryName = categoryName;
		}


		public String getResourceType() {
			return resourceType;
		}


		public void setResourceType(String resourceType) {
			this.resourceType = resourceType;
		}


		public String getCollegeUrl() {
			return collegeUrl;
		}


		public void setCollegeUrl(String collegeUrl) {
			this.collegeUrl = collegeUrl;
		}


		public String getCollegeFacts() {
			return collegeFacts;
		}


		public void setCollegeFacts(String collegeFacts) {
			this.collegeFacts = collegeFacts;
		}


		public String getCollegeScores() {
			return collegeScores;
		}


		public void setCollegeScores(String collegeScores) {
			this.collegeScores = collegeScores;
		}


		public String getInternationalStudentsRatio() {
			return internationalStudentsRatio;
		}


		public void setInternationalStudentsRatio(String internationalStudentsRatio) {
			this.internationalStudentsRatio = internationalStudentsRatio;
		}


		public String getMaleFemaleRatio() {
			return maleFemaleRatio;
		}


		public void setMaleFemaleRatio(String maleFemaleRatio) {
			this.maleFemaleRatio = maleFemaleRatio;
		}


		public String getCollegeResearchGrants() {
			return collegeResearchGrants;
		}


		public void setCollegeResearchGrants(String collegeResearchGrants) {
			this.collegeResearchGrants = collegeResearchGrants;
		}


		public String getAuthorName() {
			return authorName;
		}


		public void setAuthorName(String authorName) {
			this.authorName = authorName;
		}


		public String getContributorName() {
			return contributorName;
		}


		public void setContributorName(String contributorName) {
			this.contributorName = contributorName;
		}


		public String getContributorEmail() {
			return contributorEmail;
		}


		public void setContributorEmail(String contributorEmail) {
			this.contributorEmail = contributorEmail;
		}


		public String getContributorStoryLine() {
			return contributorStoryLine;
		}


		public void setContributorStoryLine(String contributorStoryLine) {
			this.contributorStoryLine = contributorStoryLine;
		}


		public String getCollegeStanding() {
			return collegeStanding;
		}


		public void setCollegeStanding(String collegeStanding) {
			this.collegeStanding = collegeStanding;
		}


		public String getCollegeGPA() {
			return collegeGPA;
		}


		public void setCollegeGPA(String collegeGPA) {
			this.collegeGPA = collegeGPA;
		}


		public String getCollegeScholarships() {
			return collegeScholarships;
		}


		public void setCollegeScholarships(String collegeScholarships) {
			this.collegeScholarships = collegeScholarships;
		}


		public String getCollegeCampusLife() {
			return collegeCampusLife;
		}


		public void setCollegeCampusLife(String collegeCampusLife) {
			this.collegeCampusLife = collegeCampusLife;
		}


		public String getCityName() {
			return cityName;
		}


		public void setCityName(String cityName) {
			this.cityName = cityName;
		}


		public String getStateName() {
			return stateName;
		}


		public void setStateName(String stateName) {
			this.stateName = stateName;
		}


		public String getCountryCode() {
			return countryCode;
		}


		public void setCountryCode(String countryCode) {
			this.countryCode = countryCode;
		}


		public String getCountryName() {
			return countryName;
		}


		public void setCountryName(String countryName) {
			this.countryName = countryName;
		}


		public String getResourceUploadedDate() {
			return resourceUploadedDate;
		}


		public void setResourceUploadedDate(String resourceUploadedDate) {
			this.resourceUploadedDate = resourceUploadedDate;
		}


		public String getCollegeLocation() {
			return collegeLocation;
		}


		public void setCollegeLocation(String collegeLocation) {
			this.collegeLocation = collegeLocation;
		}


		public String getNotes() {
			return notes;
		}


		public void setNotes(String notes) {
			this.notes = notes;
		}


		public String getLastModifiedBy() {
			return lastModifiedBy;
		}


		public void setLastModifiedBy(String lastModifiedBy) {
			this.lastModifiedBy = lastModifiedBy;
		}


		public String getLastModifiedDate() {
			return lastModifiedDate;
		}


		public void setLastModifiedDate(String lastModifiedDate) {
			this.lastModifiedDate = lastModifiedDate;
		}


		public String getLocalCampusInfo() {
			return localCampusInfo;
		}


		public void setLocalCampusInfo(String localCampusInfo) {
			this.localCampusInfo = localCampusInfo;
		}


		public String getAlumniInfo() {
			return alumniInfo;
		}


		public void setAlumniInfo(String alumniInfo) {
			this.alumniInfo = alumniInfo;
		}


		public String getProspectus() {
			return prospectus;
		}


		public void setProspectus(String prospectus) {
			this.prospectus = prospectus;
		}


		



}
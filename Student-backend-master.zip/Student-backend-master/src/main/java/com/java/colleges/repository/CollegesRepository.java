package com.java.colleges.repository;


import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.java.colleges.model.Colleges;

@Repository
public interface CollegesRepository extends MongoRepository<Colleges, String>{
	
	public List<Colleges> findAll();
	
	
	@SuppressWarnings("unchecked")
	public Colleges save(Colleges colleges);
	
	Colleges findBy_id(ObjectId _id);//MBA
	
	//@Query(value="{'categoryName' : ?0}") List<Colleges>
	//findByCategoryName(String categoryName);
	
//	@Query(value="{'categoryName' : ?0, 'countryName' : ?1, contributorEmail : {$regex : ?2}}")
//	List<Colleges> findByCategoryNameByCountryNameBycontributorEmail(String categoryName);
//	
//	@Query(value="{'categoryName' : ?0, 'countryName' : ?1, 'cityName' : ?2, contributorEmail : {$regex : ?3}}")
//	List<Colleges> getByCategoryNameByCountryNameByCityNameByContributorEmailRegexQuery(String categoryName, String countryName,String cityName,String contributorEmail);
}

//@Query("{'categoryName' : ?0, authorName : {$regex : ?1}}")
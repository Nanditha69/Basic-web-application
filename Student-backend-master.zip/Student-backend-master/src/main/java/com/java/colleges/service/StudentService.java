package com.java.colleges.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.colleges.model.Colleges;
import com.java.colleges.repository.CollegesRepository;


@Service
public class StudentService {


	@Autowired
	private CollegesRepository collegesRepository;
	
    public Colleges save(Colleges colleges){
		return collegesRepository.save(colleges);
    }	

    public List<Colleges> getAllColleges(){
		return collegesRepository.findAll();
    }

//    public List<Colleges> searchByContributorEmail(String categoryName,String countryName,String cityName, String contributorEmail){
//		return collegesRepository.getByCategoryNameByCountryNameByCityNameByContributorEmailRegexQuery(categoryName,countryName,cityName,contributorEmail);
//    }
}

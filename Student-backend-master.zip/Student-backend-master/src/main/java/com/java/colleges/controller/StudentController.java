package com.java.colleges.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.java.colleges.model.Colleges;
import com.java.colleges.service.StudentService;

@RestController
public class StudentController {
		
	@Autowired
	private StudentService studentService;
	
	@CrossOrigin
	@RequestMapping(value="/colleges",  method = RequestMethod.GET)
	public List<Colleges> getAllColleges(){
		System.out.print("UI called: ");
		return studentService.getAllColleges();
	
	}
	
	
	
	
	@CrossOrigin
	 @RequestMapping(value = "/", method = RequestMethod.POST)
	  public Colleges createCollege(@Valid @RequestBody Colleges colleges) {
		
		System.out.print("category name: "+colleges.getCategoryName());
		return studentService.save(colleges);
	  }
	
	@CrossOrigin
	 @RequestMapping(value = "/savedocument", method = RequestMethod.POST)
	  public Colleges saveCollege(@Valid @RequestBody Colleges colleges) {
		
		System.out.print("category name: "+colleges.getCategoryName());
		return studentService.save(colleges);
	  }	
	
//	@CrossOrigin
//	@RequestMapping(value="/colleges/{CategoryName}/{countryName}/{cityName}/{contributorEmail}",  method = RequestMethod.GET)
//	public List<Colleges> getAllCollegesByEmail(@PathVariable String CategoryName ,@PathVariable String countryName,@PathVariable String cityName,@PathVariable String contributorEmail){
//
//		return studentService.searchByContributorEmail(CategoryName, countryName, cityName, contributorEmail);
//	}
	
		
}



